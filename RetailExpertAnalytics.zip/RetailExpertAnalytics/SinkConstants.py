SINK_OUTPUT_PROCESSED_FOLDER_NAME = "sink.output.folder.name"
SINK_FILE_FORMAT = "sink.file.format"
SINK_OUTPUT_MODE = "sink.output.mode"
