INPUT_BASE_DIR = "input.base.dir"
OUTPUT_BASE_DIR = "output.base.dir"
