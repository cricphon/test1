SOURCE_FILE_FORMAT = "source.file.format"
ORDERS_DATA_PATH = "source.orders.data"
ORDER_ITEMS_DATA_PATH = "source.order_items.data"
