INPUT_BASE_DIR_S3 = "input.base.dir.s3"
OUTPUT_BASE_DIR_S3 = "output.base.dir.s3"
